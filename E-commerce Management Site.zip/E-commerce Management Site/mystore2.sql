-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2023 at 04:27 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mystore`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_details`
--

CREATE TABLE `admin_details` (
  `id` int(50) NOT NULL,
  `full_name` varchar(55) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL,
  `brand_title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(1, 'Swiggy'),
(3, 'Amazon'),
(4, 'Nike'),
(5, 'Loto'),
(6, 'Zomato'),
(7, 'Flipcart'),
(8, 'Pizza Hut'),
(9, 'KFC'),
(10, 'Dominos'),
(11, 'Nino Rossi'),
(12, 'Cats Eye'),
(13, 'Zara'),
(14, 'Fish Bazaar'),
(15, 'Meat Market');

-- --------------------------------------------------------

--
-- Table structure for table `cart_details`
--

CREATE TABLE `cart_details` (
  `product_id` int(11) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart_details`
--

INSERT INTO `cart_details` (`product_id`, `ip_address`, `quantity`) VALUES
(1, '::1', 0),
(2, '::1', 0),
(5, '::1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_title`) VALUES
(1, 'Fish'),
(2, 'Meat'),
(3, 'Juices'),
(4, 'Shoes'),
(5, 'Fruits'),
(6, 'Vegetables'),
(7, 'Fast Food'),
(9, 'mens shoes'),
(10, 'womens shoes'),
(11, 'Mens Clothing'),
(12, 'Womens Clothing');

-- --------------------------------------------------------

--
-- Table structure for table `orders_pending`
--

CREATE TABLE `orders_pending` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `invoice_number` int(255) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(255) NOT NULL,
  `order_status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders_pending`
--

INSERT INTO `orders_pending` (`order_id`, `user_id`, `invoice_number`, `product_id`, `quantity`, `order_status`) VALUES
(1, 1, 1478193742, 1, 1, 'pending'),
(2, 1, 1033013926, 1, 1, 'pending'),
(3, 1, 891421110, 1, 1, 'pending'),
(4, 1, 689632139, 2, 1, 'pending'),
(5, 1, 1084019639, 3, 1, 'pending'),
(6, 1, 141085761, 3, 1, 'pending'),
(7, 1, 2074655321, 2, 1, 'pending'),
(8, 1, 1325303620, 3, 1, 'pending'),
(9, 1, 1890722648, 3, 1, 'pending'),
(10, 1, 1470717778, 15, 1, 'pending'),
(11, 1, 365539543, 15, 1, 'pending'),
(12, 1, 560261598, 9, 1, 'pending'),
(13, 1, 1643558556, 3, 1, 'pending'),
(14, 1, 154669573, 14, 1, 'pending'),
(15, 1, 2039072514, 4, 1, 'pending'),
(16, 1, 1585936513, 8, 1, 'pending'),
(17, 1, 537710966, 5, 1, 'pending'),
(18, 1, 446142092, 12, 1, 'pending'),
(19, 1, 211464278, 5, 1, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_title` varchar(100) NOT NULL,
  `product_description` varchar(255) NOT NULL,
  `product_keywords` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `product_image1` varchar(255) NOT NULL,
  `product_image2` varchar(255) NOT NULL,
  `product_image3` varchar(255) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_title`, `product_description`, `product_keywords`, `category_id`, `brand_id`, `product_image1`, `product_image2`, `product_image3`, `product_price`, `date`, `status`) VALUES
(1, 'Fresh mango', 'Eat once and you will ask for more', 'mango,fresh mango,zomato,green mangoes,good mangoes', 5, 6, 'mango1.jpg', 'mango2.jpg', 'mango3.jpg', '200', '2023-06-30 18:15:53', 'true'),
(2, 'Fresh Apples', 'An apple a day keeps the doctor away', 'apple,fresh apple,green apple,swiggy,red apple', 5, 1, 'apple.jpg', 'apple1.jpg', 'apple2.jpg', '300', '2023-07-02 18:05:55', 'true'),
(3, 'Capsicum', 'Fresh capsicums from our gardens to your doorstep', 'capsicum,green capsicum,yellow capsicum,fresh capsicum', 6, 7, 'capsicum.jpg', 'capsicum1.jpg', 'capsicum2.jpg', '80', '2023-07-02 18:13:45', 'true'),
(4, 'Burger', 'Mc Donalds serves their famous burgers to you', 'burger, Burger', 7, 2, 'burger1.jpg', 'burger2.jpg', '3.jpeg', '250', '2023-08-07 19:31:30', 'true'),
(5, 'PizzaHut', 'pizza huts pizza at your doorstep', 'pizza hut,pizza', 7, 8, 'pizza1.jpg', 'pizza2.jpg', 'pizza3.jpg', '350', '2023-08-08 02:08:12', 'true'),
(6, 'Dominos', 'Dominos Pizza at your doorstep', 'dominos,pizza', 7, 10, 'domi1.jpg', 'domi2.jpg', 'domi3.jpg', '400', '2023-08-08 02:09:41', 'true'),
(7, 'KFC', 'kfc serves their best quality food to you', 'kfc,fast food', 7, 9, 'kfc1.jpg', 'kfc2.jpeg', 'kfc3.jpeg', '400', '2023-08-08 02:12:22', 'true'),
(8, 'Nike', 'Nike products now you can get', 'nike,shoes,mens shoes', 9, 4, 'nike1.png', 'nike2.jpeg', 'nike3.jpg', '400', '2023-08-08 02:29:44', 'true'),
(9, 'Lotto', 'Lottos products we deliver at fair price', 'lotto,shoes', 9, 5, 'lotto1.jpg', 'lotto2.jpg', 'lotto3.jpg', '450', '2023-08-08 02:34:00', 'true'),
(10, 'Nino Rossi', 'Nino Rossi has very high quality product for women', 'nino rossi,shoes', 10, 11, 'nino1.jpeg', 'nino2.jpg', 'nino3.jpeg', '500', '2023-08-08 02:35:53', 'true'),
(11, 'Cats Eye', 'Best mens clothings for men', 'mens clothing,shirt', 11, 12, 'cats1.jpeg', 'cats2.jpeg', 'cats3.jpg', '500', '2023-08-08 02:53:05', 'true'),
(12, 'Zara', 'Zara brings the best dresses for women', 'dress,womens clothing', 12, 13, 'dress1.jpg', 'dress2.jpg', 'dress3.jpeg', '550', '2023-08-08 02:54:02', 'true'),
(13, 'Fish Bazaar', 'Fish Bazaar serves the best quality of Hilsha fish', 'fish,fish bazaar', 1, 14, 'fish1.jpg', 'fish2.jpg', 'fish3.jpg', '600', '2023-08-08 04:30:17', 'true'),
(14, 'Meat Market', 'Meat Markets products are very good in quality', 'meat,meat market', 2, 15, 'meat1.jpeg', 'meat2.jpeg', 'meat3.jpg', '500', '2023-08-08 03:03:17', 'true'),
(15, 'Juice Shop', 'Juice Shop brings variety of juices', 'juice,juices', 3, 16, 'juice1.jpeg', 'juice2.jpeg', 'juice3.jpg', '300', '2023-08-08 03:05:36', 'true');

-- --------------------------------------------------------

--
-- Table structure for table `user_orders`
--

CREATE TABLE `user_orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount_due` int(255) NOT NULL,
  `invoice_number` int(255) NOT NULL,
  `total_products` int(255) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `order_status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_orders`
--

INSERT INTO `user_orders` (`order_id`, `user_id`, `amount_due`, `invoice_number`, `total_products`, `order_date`, `order_status`) VALUES
(1, 1, 200, 1478193742, 1, '2023-08-07 02:04:15', 'Complete'),
(2, 1, 200, 1033013926, 1, '2023-08-07 08:52:50', 'Complete'),
(3, 1, 200, 891421110, 1, '2023-08-07 13:21:48', 'Complete'),
(4, 1, 300, 689632139, 1, '2023-11-13 17:15:08', 'Complete'),
(5, 1, 580, 1084019639, 3, '2023-08-07 02:21:30', 'Complete'),
(6, 1, 80, 141085761, 1, '2023-08-07 02:44:15', 'Complete'),
(7, 1, 300, 2074655321, 1, '2023-08-07 08:54:15', 'Complete'),
(8, 1, 280, 1325303620, 2, '2023-08-07 12:53:26', 'pending'),
(9, 1, 80, 1890722648, 1, '2023-08-07 13:06:27', 'Complete'),
(10, 1, 800, 1470717778, 2, '2023-08-08 03:27:11', 'pending'),
(11, 1, 300, 365539543, 1, '2023-08-08 04:17:52', 'pending'),
(12, 1, 450, 560261598, 1, '2023-08-08 09:34:00', 'pending'),
(13, 1, 80, 1643558556, 1, '2023-08-08 09:35:55', 'pending'),
(14, 1, 800, 154669573, 2, '2023-08-08 09:37:10', 'Complete'),
(15, 1, 250, 2039072514, 1, '2023-08-08 13:07:23', 'pending'),
(16, 1, 800, 1585936513, 2, '2023-11-13 17:14:35', 'pending'),
(17, 1, 350, 537710966, 1, '2023-11-13 17:21:03', 'Complete'),
(18, 1, 950, 446142092, 2, '2023-11-14 03:12:03', 'pending'),
(19, 1, 350, 211464278, 1, '2023-11-14 03:14:14', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `user_payments`
--

CREATE TABLE `user_payments` (
  `payment_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `invoice_number` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `payment_mode` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_payments`
--

INSERT INTO `user_payments` (`payment_id`, `order_id`, `invoice_number`, `amount`, `payment_mode`, `date`) VALUES
(1, 1, 1478193742, 200, 'Cash on Delivery', '2023-08-07 02:04:15'),
(2, 5, 1084019639, 580, 'Pay offline', '2023-08-07 02:21:30'),
(3, 6, 141085761, 80, 'NetBanking', '2023-08-07 02:44:15'),
(4, 2, 1033013926, 200, 'Cash on Delivery', '2023-08-07 08:52:50'),
(5, 7, 2074655321, 300, 'Paypal', '2023-08-07 08:54:15'),
(6, 9, 1890722648, 80, 'Cash on Delivery', '2023-08-07 13:06:27'),
(7, 3, 891421110, 200, 'NetBanking', '2023-08-07 13:21:48'),
(8, 14, 154669573, 800, 'Select Payment Mode', '2023-08-08 09:37:10'),
(9, 4, 689632139, 300, 'NetBanking', '2023-11-13 17:15:08'),
(10, 17, 537710966, 350, 'Paypal', '2023-11-13 17:21:03');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_image` varchar(255) NOT NULL,
  `user_ip` varchar(100) NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `user_mobile` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`user_id`, `username`, `user_email`, `user_password`, `user_image`, `user_ip`, `user_address`, `user_mobile`) VALUES
(1, 'Shrabani', 'shrabani123@gmail.com', '$2y$10$NxJv7RQe9CxNH/.l3.azdujBnMoAKMMEYIQDSgCkx87r0DvKB/nNK', 'shrabani2.jpg', '::1', 'Dhaka', '34567'),
(2, 'john ', 'john@gmail.com', '$2y$10$90pkuiRXB5PpPlh7o/R95u5Z5Ve8WY7hPsNjkYSxqdgsJXzKXg2hC', 'john.jpeg', '::1', 'Norway', '56464'),
(3, 'aa', 'aa@gmail.com', '$2y$10$yr7DJEcyAttymqxHLv6j0.cTXp9CD2LvePtst4tZJhkvu8HLg./xa', 'admin.png', '::1', 'rfergfe', '32434535'),
(4, 'miaw', 'miaw@gmail.com', '$2y$10$RLkByydmon8wayBjnHxbn.Adp70WePAfNV6tEOJlYKeOnGDfFk5D.', 'dairy.jpg', '::1', 'mumbai', '34356');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_details`
--
ALTER TABLE `admin_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart_details`
--
ALTER TABLE `cart_details`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `orders_pending`
--
ALTER TABLE `orders_pending`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `user_orders`
--
ALTER TABLE `user_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `user_payments`
--
ALTER TABLE `user_payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_details`
--
ALTER TABLE `admin_details`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `orders_pending`
--
ALTER TABLE `orders_pending`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `user_orders`
--
ALTER TABLE `user_orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `user_payments`
--
ALTER TABLE `user_payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
