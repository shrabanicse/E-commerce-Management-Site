<div class="bg-info p-3 text-center">
    <p>All rights reserved</p>
</div>